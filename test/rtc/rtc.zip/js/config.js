// var domain = 'lccsp.zgpajf.com.cn';
// var wss = 'wss://lccsp.zgpajf.com.cn:5092/wss';

var domain = 'pro.vsbc.com';
var wss = 'wss://pro.vsbc.com:60040/wss';

// var domain = 'rtc.vsbc.com';
// var wss = 'wss://rtc.vsbc.com:5092/wss';